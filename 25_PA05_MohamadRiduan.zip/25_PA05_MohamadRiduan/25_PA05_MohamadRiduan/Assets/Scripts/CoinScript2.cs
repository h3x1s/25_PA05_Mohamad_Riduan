﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class CoinScript2 : MonoBehaviour
{
    public Text score;
    private int scoreValue = 0;

    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Coin")
        {
            other.gameObject.SetActive(false);
            scoreValue += 1;
            SetScore();
        }
    }


    void SetScore()
    {
        score.text = "Coins Collected : " + scoreValue;
        if (scoreValue == 4)
        {
            SceneManager.LoadScene("Win");
        }
    }


    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
