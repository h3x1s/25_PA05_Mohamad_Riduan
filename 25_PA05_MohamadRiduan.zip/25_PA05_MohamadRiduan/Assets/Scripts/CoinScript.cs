﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
public class CoinScript : MonoBehaviour
{

    public int Coin;
    public Text CoinText;
    
    
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    void OnCollisionEnter(Collision collision)
    {
        if(collision.collider.tag == "Player")
        {
         
            Destroy(gameObject);
            Coin++;
            CoinText.text = "Coins Collected :" + Coin;
        }
    }
    
}
